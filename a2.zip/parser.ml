type token =
  | FLOAT of (float)
  | LPAREN
  | RPAREN
  | LBRAC
  | RBRAC
  | COMMA
  | COLON
  | INDEX of (int * int)
  | RANGE of ((int * int) * (int * int))
  | COUNT
  | ROWCOUNT
  | COLCOUNT
  | SUM
  | ROWSUM
  | COLSUM
  | AVG
  | ROWAVG
  | COLAVG
  | MIN
  | ROWMIN
  | COLMIN
  | MAX
  | ROWMAX
  | COLMAX
  | ADD
  | SUBT
  | MULT
  | DIV
  | ASSIGN
  | SEMICOLON
  | EOF

open Parsing;;
let _ = parse_error;;
let yytransl_const = [|
  258 (* LPAREN *);
  259 (* RPAREN *);
  260 (* LBRAC *);
  261 (* RBRAC *);
  262 (* COMMA *);
  263 (* COLON *);
  266 (* COUNT *);
  267 (* ROWCOUNT *);
  268 (* COLCOUNT *);
  269 (* SUM *);
  270 (* ROWSUM *);
  271 (* COLSUM *);
  272 (* AVG *);
  273 (* ROWAVG *);
  274 (* COLAVG *);
  275 (* MIN *);
  276 (* ROWMIN *);
  277 (* COLMIN *);
  278 (* MAX *);
  279 (* ROWMAX *);
  280 (* COLMAX *);
  281 (* ADD *);
  282 (* SUBT *);
  283 (* MULT *);
  284 (* DIV *);
  285 (* ASSIGN *);
  286 (* SEMICOLON *);
    0 (* EOF *);
    0|]

let yytransl_block = [|
  257 (* FLOAT *);
  264 (* INDEX *);
  265 (* RANGE *);
    0|]

let yylhs = "\255\255\
\001\000\000\000"

let yylen = "\002\000\
\000\000\002\000"

let yydefred = "\000\000\
\001\000\000\000\002\000"

let yydgoto = "\002\000\
\003\000"

let yysindex = "\255\255\
\000\000\000\000\000\000"

let yyrindex = "\000\000\
\000\000\000\000\000\000"

let yygindex = "\000\000\
\000\000"

let yytablesize = 0
let yytable = "\001\000"

let yycheck = "\001\000"

let yynames_const = "\
  LPAREN\000\
  RPAREN\000\
  LBRAC\000\
  RBRAC\000\
  COMMA\000\
  COLON\000\
  COUNT\000\
  ROWCOUNT\000\
  COLCOUNT\000\
  SUM\000\
  ROWSUM\000\
  COLSUM\000\
  AVG\000\
  ROWAVG\000\
  COLAVG\000\
  MIN\000\
  ROWMIN\000\
  COLMIN\000\
  MAX\000\
  ROWMAX\000\
  COLMAX\000\
  ADD\000\
  SUBT\000\
  MULT\000\
  DIV\000\
  ASSIGN\000\
  SEMICOLON\000\
  EOF\000\
  "

let yynames_block = "\
  FLOAT\000\
  INDEX\000\
  RANGE\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    Obj.repr(
# 32 "parser.mly"
        ()
# 143 "parser.ml"
               : unit))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : unit)
